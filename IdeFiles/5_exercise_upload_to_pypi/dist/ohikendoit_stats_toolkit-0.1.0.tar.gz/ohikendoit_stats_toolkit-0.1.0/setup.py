from setuptools import setup

setup(name='ohikendoit_stats_toolkit',
      version='0.1.0',
      description='Gaussian and Binomial distributions',
      packages=['ohikendoit_stats_toolkit'],
      author = 'Yoonseong Jung',
      author_email = 'ohikendoit@gmail.com',
      zip_safe=False)
